import DataStructs.Month;
import Main.Main;

import java.io.*;
import java.text.Format;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.StringTokenizer;

import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;

public class CSVwritertest {

    public static String pathedit = "C:\\Users\\Dell\\IdeaProjects\\Csv for Workhours\\Work hours eddited\\Work hours.csv";
    public static String testpath = "C:\\Users\\Dell\\IdeaProjects\\Csv for Workhours\\Work hours.csv";


    public static void CSVwritertestCSV(Month[] Years) throws IOException {
        File csvFile = new File(pathedit);
        FileWriter fileWriter = new FileWriter(csvFile);
        //write header line here if you need
        String header = "Date,working hours,";
        fileWriter.write(header+"\n");

        for (Month Months : Years) {
            StringBuilder line = new StringBuilder();
            if(Months == Years[0]){
                line.insert(0,header);
            }
            for (int i = 1; i < 32; i++) {
                if(Months.Days[i] != null){
                    line.append("\"");
                    line.append(Months.Days[i].Date +","+Months.Days[i].Hours+",,,");
                    line.append("\"");}
                if (i == Months.Days.length - 1) {
                    line.append("Total Sum" + "," + Months.getTotal());
                    line.append(",,,");
                }
            }

            line.append("\n");
            fileWriter.write(line.toString());


        }
        fileWriter.close();
    }

//    public static void main(String[] args){
//        String str = ""tomanyquotes"";
//    }


}


